package br.com.murillo.canvasdesk.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

/** One coordinate basis for topology, document projection and front-face rendering. */
public final class BoardPlane {
    private BoardPlane() {}
    public static Direction right(Direction front) { return front.getCounterClockWise(); }
    public static Direction[] sides(Direction front) {
        return new Direction[]{right(front), right(front).getOpposite(), Direction.UP, Direction.DOWN};
    }
    public static double horizontal(Direction front, BlockPos from, BlockPos to) {
        Direction right = right(front);
        return (to.getX() - from.getX()) * right.getStepX() + (to.getZ() - from.getZ()) * right.getStepZ();
    }
    public static double vertical(BlockPos from, BlockPos to) { return from.getY() - to.getY(); }
}
