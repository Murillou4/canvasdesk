package br.com.murillo.canvasdesk.client.render;

import br.com.murillo.canvasdesk.block.DeskBlockEntity;
import br.com.murillo.canvasdesk.block.DeskBlock;
import br.com.murillo.canvasdesk.block.BoardPlane;
import net.minecraft.core.Direction;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;

public final class DeskRenderer implements BlockEntityRenderer<DeskBlockEntity,DeskRenderer.State> {
    public DeskRenderer(BlockEntityRendererProvider.Context context){}
    public static final class State extends BlockEntityRenderState { Identifier texture; Direction facing; }
    @Override public State createRenderState(){return new State();}
    @Override public void extractRenderState(DeskBlockEntity desk,State state,float partialTick,Vec3 camera,ModelFeatureRenderer.CrumblingOverlay overlay){
        BlockEntityRenderer.super.extractRenderState(desk,state,partialTick,camera,overlay);state.texture=SurfaceCache.texture(desk.getBlockPos());state.facing=desk.getBlockState().getValue(DeskBlock.FACING);
    }
    @Override public void submit(State state,PoseStack pose,SubmitNodeCollector collector,CameraRenderState camera){
        if(state.texture==null)return;int light=state.lightCoords;
        collector.submitCustomGeometry(pose,RenderTypes.entityTranslucent(state.texture),(matrix,vertices)->{
            vertex(vertices,matrix,state.facing,0,0,light);vertex(vertices,matrix,state.facing,0,1,light);
            vertex(vertices,matrix,state.facing,1,1,light);vertex(vertices,matrix,state.facing,1,0,light);
        });
    }
    private static void vertex(VertexConsumer vertices,PoseStack.Pose pose,Direction facing,float u,float v,int light){
        Direction right=BoardPlane.right(facing);
        float x=.5F+right.getStepX()*(u-.5F)+facing.getStepX()*.0635F;
        float z=.5F+right.getStepZ()*(u-.5F)+facing.getStepZ()*.0635F;
        vertices.addVertex(pose,x,1-v,z).setColor(0xffffffff).setUv(u,v).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose,facing.getStepX(),0,facing.getStepZ());
    }
    @Override public int getViewDistance(){return 64;}
}
