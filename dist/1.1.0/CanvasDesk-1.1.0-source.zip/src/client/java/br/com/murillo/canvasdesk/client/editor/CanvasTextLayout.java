package br.com.murillo.canvasdesk.client.editor;

import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import java.util.ArrayList;
import java.util.List;

/** Layout is measured once in document units by all three consumers: GUI, tiles and hit targets. */
public record CanvasTextLayout(double scale, double padding, double boxSize, double textX,
                               double height, List<Line> lines, List<Check> checks) {
    public record Line(FormattedCharSequence value,double y) {}
    public record Check(int index,double y) {}
    public static CanvasTextLayout of(Font font,CanvasElementView e) {
        double scale=e.fontSize/9, pad=e.type.equals("TEXT")?0:9*scale;
        boolean checklist=e.type.equals("CHECKLIST");double textX=pad+(checklist?14*scale:0);
        int wrap=Math.max(1,(int)Math.floor((e.w-textX-pad)/scale));
        List<Line> lines=new ArrayList<>();List<Check> checks=new ArrayList<>();double y=pad;
        String[] rows=e.text.split("\n",-1);
        for(int i=0;i<rows.length;i++) {
            if(checklist)checks.add(new Check(i,y));
            var wrapped=font.split(Component.literal(rows[i]),wrap);
            if(wrapped.isEmpty())y+=12*scale;
            else for(var line:wrapped){lines.add(new Line(line,y));y+=12*scale;}
        }
        return new CanvasTextLayout(scale,pad,8*scale,textX,y+pad,List.copyOf(lines),List.copyOf(checks));
    }
    public int checkAt(double x,double y) {
        double hit=Math.max(boxSize,12*scale);
        if(x<padding-2*scale||x>padding+hit)return -1;
        for(Check check:checks)if(y>=check.y-2*scale&&y<=check.y+hit)return check.index;
        return -1;
    }
}
