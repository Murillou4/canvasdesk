# Canvas Desk

Um quadro branco modular para Minecraft Java **26.3**, Fabric e **Java 25**. Moldura de madeira, encaixes de cobre, bandeja e suporte acompanham uma superfície vertical onde desenhos, textos e diagramas permanecem salvos no mundo.

## Instalação

1. Instale o Fabric Loader **0.19.5** para Minecraft **26.3**.
2. Coloque `canvasdesk-1.1.0.jar` e **Fabric API 0.164.0+26.3** na pasta `mods` da instância.
3. Em multiplayer, instale os dois mods no servidor e nos clientes. Use Java 25.

Este projeto é independente do MurilloUtils. O JAR não é compatível com Minecraft 1.21.11. A entrega não modifica sua instalação pessoal.

A versão 1.1.0 desta entrega é para teste com amigos. A validação adicional foi dispensada pelo usuário; a conclusão do teste com dois clientes permanece pendente. Clientes e servidor devem usar o mesmo JAR e a mesma versão de Minecraft/Fabric API.

## Construção e uso

Fabrique um módulo com a seguinte receita (qualquer tipo de tábuas):

```text
Papel   Papel    Papel
Cobre   Redstone Cobre
Tábuas  Tábuas   Tábuas
```

Encontre o quadro na aba criativa **Canvas Desk** ou fabrique-o. O painel fica voltado para você e pode crescer para os lados e para cima. Para herdar a orientação, coloque uma expansão pela lateral ou pelo topo de um painel existente. Conectam-se somente módulos no mesmo plano e com a mesma orientação. Cada painel exibe 256 × 256 unidades do documento, da esquerda para a direita e de cima para baixo. Clique com o botão direito para editar. As alterações aparecem na superfície vertical real, inclusive através das emendas; buracos permanecem vazios.

As molduras acompanham as bordas expostas. A bandeja e os pés ficam na base inferior do conjunto; módulos superiores não repetem os suportes. A versão 1.1.0 substitui a geometria horizontal diretamente, conforme solicitado para este projeto sem mundos de uso existentes.

| Controle | Ação |
| --- | --- |
| V / B / E | Seleção / desenho / borracha |
| T / N / C | Texto / nota / lista |
| R / O / L / A / K | Retângulo / elipse / linha / seta / conector |
| H ou Espaço + arraste | Navegar |
| Botão do meio + arraste | Navegar |
| Roda do mouse | Zoom em torno do cursor |
| F | Enquadrar o conteúdo |
| Shift + seleção | Acrescentar à seleção |
| Alt + clique | Selecionar grupo visível de uma união |
| Enter / duplo clique | Editar texto selecionado |
| Ctrl + Enter | Salvar o diálogo de texto |
| Fonte | Ajustar texto, notas e listas entre 8 e 96 unidades |
| Delete | Excluir seleção |
| Ctrl + Z / Ctrl + Y | Desfazer / refazer |
| Esc | Fechar diálogo ou editor |

Arraste no espaço vazio com a ferramenta de seleção para selecionar vários elementos. O canto inferior direito da seleção redimensiona o elemento. A borracha remove elementos completos. Selecione dois elementos com a ferramenta de conector para criar uma ligação que acompanha seus movimentos. Cor e espessura podem ser alteradas na barra e aplicadas à seleção.

Novas listas usam fonte 18, caixas 16 e linhas com espaçamento 24. O controle **Fonte** aplica-se aos elementos de texto selecionados. A altura cresce quando necessário ao editar ou aumentar a fonte. Redimensionar uma lista mantém sua proporção e escala texto, caixas e margens juntos. Documentos antigos sem `fontSize` mantêm fonte 9 e podem ser ampliados pelo mesmo controle. Tamanho e marcações são salvos no servidor e participam do histórico individual.

## Documentos, conexões e acesso

- Partes separadas continuam ligadas ao mesmo documento. Remover uma ponte não divide nem copia os desenhos.
- Quebrar um módulo devolve um item vinculado ao documento. Recolocá-lo isoladamente restaura sua região; conectado, ele adota a projeção da superfície existente.
- Reconexões com projeções diferentes preservam a superfície mais antiga. Isso pode mudar a região exibida na outra parte, sem mover ou apagar os desenhos.
- Mesas do mesmo dono podem unir automaticamente quando esse dono fizer a conexão. Donos diferentes precisam aprovar na opção **Acesso e uniões**. Os donos e convidados resultantes são mostrados antes da aprovação.
- A união preserva os elementos e grupos de origem. O histórico de desfazer anterior à união é reiniciado para evitar aplicar operações em coordenadas antigas.
- Donos convidam ou removem editores. Outros jogadores próximos podem ler. A proteção do documento não transforma o bloco em uma área protegida: a quebra continua seguindo as regras do mundo.
- O histórico guarda até 100 ações por jogador. Uma alteração posterior de outro jogador impede desfazer aquele elemento silenciosamente.

## Recuperação e backup

Mesmo que os itens sejam destruídos, o conteúdo permanece no mundo:

```text
/canvasdesk list
/canvasdesk recover <UUID-do-documento>
```

Donos podem recuperar seus documentos; operadores podem recuperar documentos administrativamente. Recuperar produz outra referência ao mesmo documento, sem duplicar seu conteúdo. Referências transportadas de outro mundo não importam os dados ausentes.

Faça backup do **mundo inteiro**, incluindo a pasta `canvasdesk`. Ela contém os documentos, índices, objetos imutáveis, snapshots e o registro de operações. Não copie apenas `snapshot.json` e não edite os arquivos durante o jogo. O registro histórico e objetos antigos são mantidos para recuperação; não há limpeza automática destrutiva.

Depois de uma queda, alterações confirmadas do documento permanecem recuperáveis. Os chunks vanilla são reconciliados separadamente: uma união confirmada pode sobreviver mesmo que o Minecraft reverta a colocação do bloco que conectava as partes.

## Compilação e validação

Requisitos: JDK 25 e acesso aos repositórios oficiais na primeira compilação. O wrapper fixa Gradle 9.6.0; o projeto fixa Loom 1.17.21 e dependências de release.

```powershell
$env:JAVA_HOME = 'C:\caminho\para\jdk-25'
$env:Path = "$env:JAVA_HOME\bin;$env:Path"
.\gradlew.bat --no-daemon --console=plain clean build
```

Artefatos: `build/libs/canvasdesk-1.1.0.jar` e `build/libs/canvasdesk-1.1.0-sources.jar`. Os testes de cliente ficam em um source set separado e não são incluídos no JAR distribuível. Consulte **VALIDATION_STATUS.md** para os resultados reais, comandos, evidências e limitações.

Para apenas gerar os arquivos, sem executar testes: `./gradlew.bat --no-daemon --console=plain release -x test -x check`. A pasta `dist/1.1.0` contém o JAR, fontes Java, projeto fonte completo e `SHA256SUMS.txt`.

Quando quiser validar novamente, `tools/validate-runtime.ps1 -JdkPath C:\caminho\para\jdk-25` executa build limpo, cliente em mundo descartável, capturas visuais, dois clientes por loopback e servidor dedicado. As opções `-SkipBuild`, `-SkipSingleplayer`, `-SkipVisual`, `-SkipMultiplayer` e `-SkipDedicated` selecionam as etapas. A carga de 1.024 módulos/10 mil elementos roda no servidor sem janela; o cliente visual não executa essa carga por padrão. Evidências ficam em `artifacts/runtime`, `artifacts/visual`, `artifacts/multiplayer` e `artifacts/dedicated`; execuções antigas ficam em `artifacts/history`.

Os modelos, texturas e ícones próprios podem ser regenerados por `tools/generate-assets.py`. As fontes editáveis e a validação estática estão em `art/`. A prévia de authoring não substitui as capturas do Minecraft.

Código organizado em `block`, `core`, `server`, `network` e `client`, com editor e renderização isolados no cliente. A renderização usa cache LRU com orçamento de 32 MiB para pixels, resolução 256 perto e 64 à distância, e reposição de regiões descartadas. O documento persistido é vetorial. O quadro não tem limite configurado de módulos; continuam valendo os recursos disponíveis e os limites do próprio Minecraft.

Licença MIT. Não é um produto oficial de Minecraft, Mojang ou Microsoft.
