# Canvas Desk 1.1.0 — entrega para teste com amigos

Data: 28/10/2026. Minecraft 26.3, Fabric Loader 0.19.5, Fabric API 0.164.0+26.3, Java 25, Loom 1.17.21 e Gradle 9.6.0.

O usuário solicitou interromper a validação restante e gerar o JAR. Esta entrega não representa aprovação completa do multiplayer. Nenhum teste adicional será iniciado para o empacotamento.

## Resultados obtidos antes da interrupção

| Verificação | Estado | Evidência |
| --- | --- | --- |
| Build limpo e 24 testes de armazenamento/carga | PASS | `artifacts/build.log`, `build/reports/tests/test/index.html` |
| Recursos, traduções, receita, loot e 128 estados multipart | PASS | `art/resource-validation.json` |
| Receita real, colocação, quatro orientações, expansão vertical, L, buraco e chunk | PASS | `artifacts/runtime/summary.json` |
| Ferramentas, cor personalizada, checklist maior, fonte, resize proporcional, histórico e leitura | PASS | `artifacts/runtime/ui-selftest.log` |
| Quebra, recolocação, recuperação e reabertura real do mundo | PASS | `artifacts/runtime/gameplay-selftest.log` |
| Capturas a três blocos, 1280×720 e 854×480, quatro frentes sem espelhamento | PASS | `artifacts/visual/visual-selftest.log`, `artifacts/visual/*.png` |
| Cliente normal, sem sincronizador de GameTest | PASS | `artifacts/performance/summary.json`: mínimo 29, mediana 30 FPS, 12 amostras, limite configurado em 30 FPS, 854×480 e distância de renderização 3 |
| Servidor dedicado sem classes de cliente; 1.024 blocos e 10 mil elementos | PASS | `artifacts/dedicated/summary.json` |
| Reinício dedicado preservando 1.024 módulos, 10 mil elementos e projeções | PASS | `artifacts/dedicated/restart-summary.json` |
| Conclusão da colaboração com dois clientes reais | NOT_RUN | Tentativas bloqueadas por whitelist/limite de uma vaga do ambiente de testes. Configuração ajustada; repetição dispensada pelo usuário. |
| Novos testes após o pedido de interrupção | NOT_RUN | Intencionalmente dispensados. |
| Queda forçada do sistema e FPS com 10 mil elementos no cliente | NOT_RUN | Recuperação de journal corrompido coberta pelos testes unitários; carga pesada separada do cliente visual. |

O relatório da suíte singleplayer declara dois clientes como NOT_RUN porque seu escopo é um cliente e servidor integrado. As tentativas multiplayer não produziram uma aprovação e foram encerradas. Os registros anteriores permanecem em `artifacts/history` e `artifacts/multiplayer`.

## Desempenho e correções

O fluxo anterior executava a carga pesada junto do sincronizador visual de GameTest, bloqueando quadros durante operações de servidor. A carga agora roda em um processo dedicado sem janela. A medição de 29–30 FPS foi feita no cliente normal com teto de 30 FPS; não é uma medição do FPS máximo da placa.

Na carga dedicada: colocação de 1.024 módulos em 5.487 ms, gravação de 10 mil elementos em 32.865 ms e consulta fria de uma região com 16 elementos em 139 ms. Heap instantâneo: 331.501.240 bytes antes e 222.159.480 depois; houve coleta de lixo, portanto esses valores não representam pico de memória.

Foram corrigidos o foco da entrada de cor, descarte de texturas fora da thread gráfica, reposição do cache e sua fila, consentimento explícito dos donos, fechamento prematuro do armazenamento e reconciliação reentrante durante carga de chunks.

## Distribuição

Comando de empacotamento, sem testes:

```powershell
.\gradlew.bat --no-daemon --console=plain release -x test -x check
```

Arquivos em `dist/1.1.0`: `canvasdesk-1.1.0.jar`, `canvasdesk-1.1.0-sources.jar`, `CanvasDesk-1.1.0-source.zip` e `SHA256SUMS.txt`.

A instalação pessoal não foi modificada. Os processos de teste foram encerrados antes do empacotamento. Os testes de cliente usam as classes de desenvolvimento; o bootstrap do JAR em uma instância pessoal fica para o teste com os amigos.
