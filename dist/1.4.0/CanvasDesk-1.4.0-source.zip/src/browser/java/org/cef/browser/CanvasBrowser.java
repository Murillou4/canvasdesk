package org.cef.browser;

import org.cef.*;
import org.cef.callback.CefDragData;
import org.cef.handler.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;
import java.util.concurrent.CompletableFuture;
import java.util.function.*;

/** Custom OSR sink in JCEF's package; avoids a JOGL context or a visible AWT window. */
public final class CanvasBrowser extends CefBrowser_N implements CefRenderHandler {
    public interface Paint {void accept(ByteBuffer pixels,int width,int height);}
    private final Canvas canvas=new Canvas();private final Paint paint;private int mouseMask;
    public CanvasBrowser(CefClient client,String url,Paint paint){super(client,url,null,null,null,settings());this.paint=paint;canvas.setSize(1280,720);}
    private static CefBrowserSettings settings(){var s=new CefBrowserSettings();s.windowless_frame_rate=30;return s;}
    public void createImmediately(){createBrowser(getClient(),0,getUrl(),true,false,canvas,getRequestContext());}
    public Component getUIComponent(){return canvas;}
    public CefRenderHandler getRenderHandler(){return this;}
    public Rectangle getViewRect(CefBrowser browser){return new Rectangle(0,0,1280,720);}
    public boolean getScreenInfo(CefBrowser b,CefScreenInfo info){return false;}
    public Point getScreenPoint(CefBrowser b,Point p){return p;}
    public void onPopupShow(CefBrowser b,boolean show){if(!show)invalidate();}
    public void onPopupSize(CefBrowser b,Rectangle r){}
    public void onPaint(CefBrowser b,boolean popup,Rectangle[] dirty,ByteBuffer pixels,int w,int h){if(!popup&&w==1280&&h==720)paint.accept(pixels,w,h);}
    public void addOnPaintListener(Consumer<CefPaintEvent> l){}
    public void setOnPaintListener(Consumer<CefPaintEvent> l){}
    public void removeOnPaintListener(Consumer<CefPaintEvent> l){}
    public boolean onCursorChange(CefBrowser b,int cursor){return false;}
    public boolean startDragging(CefBrowser b,CefDragData d,int mask,int x,int y){return false;}
    public void updateDragCursor(CefBrowser b,int mask){}
    protected CefBrowser_N createDevToolsBrowser(CefClient c,String url,CefRequestContext r,CefBrowser_N parent,Point at){return null;}
    public CompletableFuture<BufferedImage> createScreenshot(boolean nativeResolution){return CompletableFuture.failedFuture(new UnsupportedOperationException("Use the shared frame buffer"));}
    public void mouse(int x,int y,int button,boolean down,int wheel){
        long when=System.currentTimeMillis();if(wheel!=0){sendMouseWheelEvent(new MouseWheelEvent(canvas,MouseEvent.MOUSE_WHEEL,when,0,x,y,0,false,MouseWheelEvent.WHEEL_UNIT_SCROLL,3,wheel));return;}
        if(button>=0){if(down)mouseMask|=InputEvent.getMaskForButton(button+1);else mouseMask&=~InputEvent.getMaskForButton(button+1);}
        int kind=button<0?(mouseMask==0?MouseEvent.MOUSE_MOVED:MouseEvent.MOUSE_DRAGGED):down?MouseEvent.MOUSE_PRESSED:MouseEvent.MOUSE_RELEASED;
        sendMouseEvent(new MouseEvent(canvas,kind,when,mouseMask,x,y,button<0?0:1,false,button<0?0:button+1));
    }
    public void key(int code,boolean down,int modifiers,String text){
        long when=System.currentTimeMillis();
        if(text!=null){for(char c:text.toCharArray())sendKeyEvent(new KeyEvent(canvas,KeyEvent.KEY_TYPED,when,modifiers,KeyEvent.VK_UNDEFINED,c));}
        else sendKeyEvent(new KeyEvent(canvas,down?KeyEvent.KEY_PRESSED:KeyEvent.KEY_RELEASED,when,modifiers,code,KeyEvent.CHAR_UNDEFINED));
    }
}
