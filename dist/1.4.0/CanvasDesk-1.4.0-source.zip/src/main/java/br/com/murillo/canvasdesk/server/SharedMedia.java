package br.com.murillo.canvasdesk.server;

import br.com.murillo.canvasdesk.block.*;
import br.com.murillo.canvasdesk.core.*;
import com.google.gson.*;
import java.util.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;

/** Server coordinates clocks/navigation. Browsers, images and audio stay on individual clients. */
public final class SharedMedia {
    private record Key(UUID workspace,UUID element) {}
    private record Watch(Key key,BlockPos anchor,UUID module,long lastSeen) {}
    private final MinecraftServer server;private final CanvasStore store;
    private final Map<Key,MediaTimeline> states=new HashMap<>();
    private final Map<UUID,LinkedHashMap<Key,Watch>> watchers=new HashMap<>();
    private final Map<UUID,Long> lastCommand=new HashMap<>();
    public SharedMedia(MinecraftServer server,CanvasStore store){this.server=server;this.store=store;}
    public static long now(){return System.nanoTime()/1_000_000;}
    public void receive(ServerPlayer player,JsonObject request){
        Key key=null;JsonObject result=new JsonObject();result.addProperty("kind","mediaState");
        try{
            UUID workspace=UUID.fromString(request.get("workspace").getAsString()),element=UUID.fromString(request.get("elementId").getAsString());
            key=new Key(workspace,element);result.addProperty("workspace",workspace.toString());result.addProperty("elementId",element.toString());
            BlockPos pos=BlockPos.of(request.get("pos").getAsLong());
            if(!player.level().hasChunkAt(pos)||player.distanceToSqr(pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5)>4096||!(player.level().getBlockEntity(pos) instanceof DeskBlockEntity desk)
                    ||desk.workspace==null||!desk.moduleId.toString().equals(request.get("moduleId").getAsString())||!store.resolve(desk.workspace).equals(workspace))throw new IllegalArgumentException("Mídia fora de alcance ou módulo alterado.");
            JsonObject e=store.element(workspace,element);if(e==null||!e.get("type").getAsString().equals("EMBED"))throw new IllegalArgumentException("Embed indisponível.");
            if(!DeskServer.get(server).elementOnSurface(player,pos,e))throw new IllegalArgumentException("Embed não aparece nessa superfície.");
            String url=e.get("url").getAsString();MediaTimeline timeline=states.get(key);if(timeline!=null&&!timeline.source.equals(url)){end(key,"A fonte do embed mudou.");timeline=null;}if(timeline==null){timeline=new MediaTimeline(url,now());states.put(key,timeline);}
            var watches=watchers.computeIfAbsent(player.getUUID(),p->new LinkedHashMap<>());watches.put(key,new Watch(key,pos,desk.moduleId,now()));while(watches.size()>8)watches.remove(watches.keySet().iterator().next());
            if(request.get("action").getAsString().equals("mediaControl")){
                if(player.isSpectator()||player.distanceToSqr(pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5)>100||!player.mayInteract(player.level(),pos)||!store.canEdit(workspace,player.getUUID()))throw new IllegalArgumentException("Somente donos e convidados próximos podem controlar.");
                long time=now();if(time-lastCommand.getOrDefault(player.getUUID(),-1000L)<50)throw new IllegalArgumentException("Aguarde a confirmação do controle.");lastCommand.put(player.getUUID(),time);
                if(!request.get("source").getAsString().equals(url))throw new IllegalArgumentException("O endereço do embed mudou.");
                if(!request.has("mediaSession")||!request.get("mediaSession").getAsString().equals(timeline.session))throw new IllegalArgumentException("A sessão de mídia mudou. Estado atualizado.");
                var hit=new net.minecraft.world.phys.BlockHitResult(net.minecraft.world.phys.Vec3.atCenterOf(pos),BoardPlane.horizontal(desk.getBlockState())?net.minecraft.core.Direction.UP:desk.getBlockState().getValue(DeskBlock.FACING),pos,false);
                if(net.fabricmc.fabric.api.event.player.UseBlockCallback.EVENT.invoker().interact(player,player.level(),net.minecraft.world.InteractionHand.MAIN_HAND,hit)!=net.minecraft.world.InteractionResult.PASS)throw new IllegalArgumentException("Interação bloqueada pela proteção do bloco.");
                if(player.level().getBlockEntity(pos)!=desk||!desk.moduleId.toString().equals(request.get("moduleId").getAsString()))throw new IllegalArgumentException("Módulo alterado durante a interação.");
                JsonObject current=store.element(workspace,element);
                if(states.get(key)!=timeline||desk.workspace==null||!store.resolve(desk.workspace).equals(workspace)||!store.canEdit(workspace,player.getUUID())||!player.mayInteract(player.level(),pos)||current==null||!current.has("url")||!current.get("url").getAsString().equals(url)||!DeskServer.get(server).elementOnSurface(player,pos,current))throw new IllegalArgumentException("Documento ou permissão alterados durante a interação.");
                timeline.command(request.get("command").getAsString(),request,request.get("mediaRevision").getAsLong(),time);broadcast(key);
            }
            result=state(player,key);result.addProperty("ok",true);
        }catch(RuntimeException error){
            if(key!=null&&states.containsKey(key))result=state(player,key);result.addProperty("ok",false);result.addProperty("message",error.getMessage());
        }
        if(request.has("nonce"))result.add("nonce",request.get("nonce"));DeskServer.send(player,result);
    }
    private JsonObject state(ServerPlayer player,Key key){JsonObject r=states.get(key).snapshot(now());r.addProperty("kind","mediaState");r.addProperty("workspace",key.workspace.toString());r.addProperty("elementId",key.element.toString());r.addProperty("editable",store.canEdit(key.workspace,player.getUUID()));return r;}
    private void broadcast(Key key){for(var watch:watchers.entrySet()){ServerPlayer p=server.getPlayerList().getPlayer(watch.getKey());if(p!=null&&watch.getValue().containsKey(key))DeskServer.send(p,state(p,key));}}
    private void end(Key key,String message){MediaTimeline old=states.remove(key);if(old==null)return;JsonObject r=old.snapshot(now());r.addProperty("kind","mediaClosed");r.addProperty("workspace",key.workspace.toString());r.addProperty("elementId",key.element.toString());r.addProperty("message",message);for(var viewer:watchers.entrySet()){var p=server.getPlayerList().getPlayer(viewer.getKey());if(p!=null&&viewer.getValue().containsKey(key))DeskServer.send(p,r);}}
    public void merged(UUID canonical){for(Key k:List.copyOf(states.keySet()))if(store.resolve(k.workspace).equals(canonical))end(k,"Documentos unidos; reprodução reiniciada.");}
    public void tick(long tick){if(tick%20!=0)return;long now=now();
        for(var viewers=watchers.entrySet().iterator();viewers.hasNext();){var entry=viewers.next();var player=server.getPlayerList().getPlayer(entry.getKey());if(player==null){viewers.remove();lastCommand.remove(entry.getKey());continue;}
            for(var it=entry.getValue().entrySet().iterator();it.hasNext();){Watch watch=it.next().getValue();
                try{if(now-watch.lastSeen>5000||!player.level().hasChunkAt(watch.anchor)||player.distanceToSqr(watch.anchor.getX()+.5,watch.anchor.getY()+.5,watch.anchor.getZ()+.5)>4096||!(player.level().getBlockEntity(watch.anchor) instanceof DeskBlockEntity desk)||!desk.moduleId.equals(watch.module)||!store.resolve(desk.workspace).equals(watch.key.workspace)){it.remove();continue;}
                    JsonObject e=store.element(watch.key.workspace,watch.key.element);MediaTimeline current=states.get(watch.key);if(current==null){it.remove();continue;}if(e==null||!e.has("url")||!e.get("url").getAsString().equals(current.source)){end(watch.key,"Embed removido ou fonte alterada.");it.remove();continue;}
                    DeskServer.send(player,state(player,watch.key));
                }catch(RuntimeException unavailable){it.remove();}
            }
            if(entry.getValue().isEmpty())viewers.remove();
        }
        Set<Key> used=new HashSet<>();watchers.values().forEach(w->used.addAll(w.keySet()));if(states.size()>1024)states.keySet().removeIf(k->!used.contains(k));
    }
}
