package br.com.murillo.canvasdesk.client;

import br.com.murillo.canvasdesk.block.*;
import br.com.murillo.canvasdesk.client.editor.*;
import br.com.murillo.canvasdesk.client.render.SurfaceCache;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.world.*;

/** Vanilla owns opening/protection. The client only remembers which visible embed was clicked. */
public final class WorldEmbedInput {
    private static String element="",module="";private static long at;
    private WorldEmbedInput() {}
    public static void register(){UseBlockCallback.EVENT.register((p,level,hand,hit)->{
        if(!level.isClientSide()||hand!=InteractionHand.MAIN_HAND||!p.getMainHandItem().isEmpty()||p.isShiftKeyDown()||DeskPlacement.chosenHand(p)!=null)return InteractionResult.PASS;
        var paper=BoardInteraction.pick(p,hit.getBlockPos(),p.getLookAngle());var tile=SurfaceCache.interaction(hit.getBlockPos());if(paper==null||tile==null)return InteractionResult.PASS;
        var uv=BoardInteraction.coordinates(level.getBlockState(hit.getBlockPos()),hit.getBlockPos(),paper.getLocation());double x=tile.x()+uv.x*256,y=tile.y()+uv.y*256;
        var e=SurfaceCache.topElement(tile,x,y);element="";module="";
        if(e!=null&&e.type.equals("EMBED")){element=e.id;module=tile.moduleId();at=System.currentTimeMillis();}
        return InteractionResult.PASS;
    });}
    public static void opened(CanvasScreen screen,JsonObject state){if(!element.isEmpty()&&System.currentTimeMillis()-at<2000&&state.has("moduleId")&&module.equals(state.get("moduleId").getAsString())){String id=element;element="";screen.focusEmbed(id);}}
}
