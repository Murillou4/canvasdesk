package br.com.murillo.canvasdesk.client.editor;

import br.com.murillo.canvasdesk.client.media.BrowserTexture;
import com.google.gson.JsonObject;
import java.awt.event.InputEvent;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.*;
import net.minecraft.client.input.*;
import net.minecraft.network.chat.Component;

/** Focused browser view uses the same native text-input ownership as Minecraft text fields. */
final class BrowserPanel implements GuiEventListener,NarratableEntry {
    private final BrowserTexture.Entry entry;private boolean focused;private int x,y,w,h,left,top,bw,bh,toolbarX,toolbarY;private EditBox seek,address;
    private long addressRevision=-1;
    BrowserPanel(BrowserTexture.Entry entry){this.entry=entry;BrowserTexture.focus(entry);}
    boolean matches(String workspace,java.util.Map<String,CanvasElementView> elements){var e=elements.get(entry.elementId);return workspace.equals(entry.workspace)&&e!=null&&e.url.equals(entry.url);}
    void build(int width,int height,Consumer<AbstractWidget> add,Runnable close){
        x=10;y=8;w=width-20;h=height-16;int rows=w-24<328?2:1;bw=Math.max(32,Math.min(w-24,(h-88-rows*24)*16/9));bh=bw*9/16;left=x+(w-bw)/2;top=y+54;
        var font=Minecraft.getInstance().font;address=new EditBox(font,x+12,y+27,Math.max(60,w-76),20,Component.literal("Endereço"));address.setMaxLength(4096);address.setValue(entry.state!=null?entry.state.get("navigationUrl").getAsString():entry.url);address.setEditable(entry.editable);add.accept(address);
        button(add,x+w-58,y+27,46,"Ir",()->entry.control("navigate",null,address.getValue(),null,null),true);
        toolbarX=x+12;toolbarY=y+h-28-(rows-1)*24;
        flow(add,30,"▶",()->entry.control("play",entry.projected().has("position")?entry.projected().get("position").getAsDouble():0,null,null,null),true);
        flow(add,30,"Ⅱ",()->entry.control("pause",entry.projected().has("position")?entry.projected().get("position").getAsDouble():0,null,null,null),true);
        seek=new EditBox(font,toolbarX,toolbarY,55,20,Component.literal("Tempo em segundos"));toolbarX+=59;seek.setMaxLength(12);seek.setValue(entry.state==null?"0":Integer.toString((int)entry.state.get("position").getAsDouble()));add.accept(seek);
        flow(add,34,"↦",()->{try{entry.control("seek",Double.parseDouble(seek.getValue().replace(',','.')),null,null,null);}catch(NumberFormatException ignored){}},true);
        flow(add,40,"Som",()->entry.volume(entry.projected().get("volume").getAsDouble()>0?0:1),false);
        flow(add,60,"Cancelar",()->BrowserTexture.cancel(entry),false);
        flow(add,55,"Reabrir",()->{BrowserTexture.reopen(entry);close.run();},false);
        button(add,x+w-68,y+3,56,"Fechar",close,false);
    }
    private void flow(Consumer<AbstractWidget> add,int width,String label,Runnable run,boolean edit){if(toolbarX+width>x+w-12){toolbarX=x+12;toolbarY+=24;}button(add,toolbarX,toolbarY,width,label,run,edit);toolbarX+=width+4;}
    private void button(Consumer<AbstractWidget> add,int x,int y,int w,String text,Runnable run,boolean edit){add.accept(new CanvasButton(x,y,w,20,text,null,run,()->false,()->!edit||entry.editable&&!entry.closed&&entry.ready&&(text.equals("Ir")?entry.mediaKind.equals("web"):!entry.mediaKind.equals("web")),null));}
    void paint(GuiGraphicsExtractor g){var client=Minecraft.getInstance();var font=client.font;address.setEditable(entry.editable&&entry.mediaKind.equals("web"));seek.setEditable(entry.editable&&!entry.mediaKind.equals("web"));if(entry.state!=null&&entry.state.has("navigationRevision")&&entry.state.get("navigationRevision").getAsLong()!=addressRevision&&!address.isFocused()){address.setValue(entry.state.get("navigationUrl").getAsString());addressRevision=entry.state.get("navigationRevision").getAsLong();}if(focused)client.textInputManager().setTextInputArea(left,top,left+bw,top+bh);g.fill(0,0,g.guiWidth(),g.guiHeight(),0x990f100e);g.fill(x,y,x+w,y+h,0xfffafaf7);g.outline(x,y,w,h,0xff967a57);g.text(font,entry.editable?"Interagir · controles compartilhados":"Assistindo · somente leitura",x+12,y+9,0xff34342e,false);g.fill(left,top,left+bw,top+bh,0xff171717);
        if(BrowserTexture.texture(entry.elementId)!=null)g.blit(entry.textureId,left,top,left+bw,top+bh,0,1,0,1);
        String info=entry.status.isBlank()?"Esc volta · vídeo, navegação e rolagem seguem o servidor":entry.status;g.text(font,font.plainSubstrByWidth(info,w-24),x+12,top+bh+4,0xff827b6d,false);
    }
    public boolean isMouseOver(double px,double py){return px>=left&&px<left+bw&&py>=top&&py<top+bh;}
    public boolean mouseClicked(MouseButtonEvent e,boolean twice){if(!isMouseOver(e.x(),e.y()))return false;if(entry.editable)mouse(e,true,0);return true;}
    public boolean mouseReleased(MouseButtonEvent e){if(focused&&entry.editable)mouse(e,false,0);return focused;}
    public void mouseMoved(double px,double py){if(focused&&entry.editable&&isMouseOver(px,py)){JsonObject c=mouseCommand(px,py,-1,false,0);entry.send(c);}}
    public boolean mouseDragged(MouseButtonEvent e,double dx,double dy){if(focused&&entry.editable){entry.send(mouseCommand(e.x(),e.y(),-1,true,0));return true;}return false;}
    public boolean mouseScrolled(double px,double py,double horizontal,double vertical){if(isMouseOver(px,py)&&entry.editable){entry.send(mouseCommand(px,py,-1,false,(int)-vertical));return true;}return false;}
    private void mouse(MouseButtonEvent e,boolean down,int wheel){entry.send(mouseCommand(e.x(),e.y(),Math.max(0,e.button()-1),down,wheel));}
    private JsonObject mouseCommand(double px,double py,int button,boolean down,int wheel){JsonObject c=new JsonObject();c.addProperty("cmd","mouse");c.addProperty("x",(int)Math.clamp((px-left)*1280/bw,0,1279));c.addProperty("y",(int)Math.clamp((py-top)*720/bh,0,719));c.addProperty("button",button);c.addProperty("down",down);c.addProperty("wheel",wheel);return c;}
    public boolean keyPressed(KeyEvent e){return key(e,true);}
    public boolean keyReleased(KeyEvent e){return key(e,false);}
    private boolean key(KeyEvent e,boolean down){if(!entry.editable)return true;JsonObject c=new JsonObject();c.addProperty("cmd","key");int scan=e.key();int code=e.shortcutKey();if(scan>=4&&scan<=29)code='A'+scan-4;else code=switch(scan){case 40->java.awt.event.KeyEvent.VK_ENTER;case 42->java.awt.event.KeyEvent.VK_BACK_SPACE;case 43->java.awt.event.KeyEvent.VK_TAB;case 44->java.awt.event.KeyEvent.VK_SPACE;case 76->java.awt.event.KeyEvent.VK_DELETE;case 79->java.awt.event.KeyEvent.VK_RIGHT;case 80->java.awt.event.KeyEvent.VK_LEFT;case 81->java.awt.event.KeyEvent.VK_DOWN;case 82->java.awt.event.KeyEvent.VK_UP;default->code;};c.addProperty("code",code);c.addProperty("down",down);c.addProperty("modifiers",(e.hasControlDown()?InputEvent.CTRL_DOWN_MASK:0)|(e.hasShiftDown()?InputEvent.SHIFT_DOWN_MASK:0)|(e.hasAltDown()?InputEvent.ALT_DOWN_MASK:0));entry.send(c);return true;}
    public boolean charTyped(CharacterEvent e){if(entry.editable&&e.isAllowedChatCharacter()){JsonObject c=new JsonObject();c.addProperty("cmd","key");c.addProperty("code",0);c.addProperty("down",true);c.addProperty("modifiers",0);c.addProperty("text",e.codepointAsString());entry.send(c);}return true;}
    public void setFocused(boolean value){if(focused!=value){focused=value;Minecraft.getInstance().onTextInputFocusChange(this,value);}}
    public boolean isFocused(){return focused;}
    public boolean capturesInput(){return focused;}
    public NarrationPriority narrationPriority(){return focused?NarrationPriority.FOCUSED:NarrationPriority.NONE;}
    public void updateNarration(NarrationElementOutput out){out.add(NarratedElementType.TITLE,Component.literal("Navegador do Canvas Desk"));}
    void close(){setFocused(false);BrowserTexture.focus(null);}
}
