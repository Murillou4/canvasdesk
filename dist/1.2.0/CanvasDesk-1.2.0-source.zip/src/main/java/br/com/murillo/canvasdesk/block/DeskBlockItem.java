package br.com.murillo.canvasdesk.block;

import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.*;
import net.minecraft.world.item.context.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public final class DeskBlockItem extends BlockItem {
    public DeskBlockItem(Block block,Properties properties){super(block,properties);}
    @Override public InteractionResult useOn(UseOnContext context){
        if(context.getPlayer()!=null) {
            var hit=new BlockHitResult(context.getClickLocation(),context.getClickedFace(),context.getClickedPos(),false);
            var result=DeskPlacement.resolve(context.getPlayer(),context.getHand(),context.getItemInHand(),hit);
            if(result!=null)return result.valid()?place(result.context()):InteractionResult.SUCCESS;
        }
        return super.useOn(context);
    }
    @Override protected BlockState getPlacementState(BlockPlaceContext context){
        if(context instanceof DeskPlacement.AssistedContext assisted)return canPlace(context,assisted.state)?assisted.state:null;
        return super.getPlacementState(context);
    }
}
