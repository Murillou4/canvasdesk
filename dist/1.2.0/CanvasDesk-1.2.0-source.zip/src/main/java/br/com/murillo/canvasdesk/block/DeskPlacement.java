package br.com.murillo.canvasdesk.block;

import net.minecraft.core.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.*;

/** The preview and the server choose the same edge, state and target. Vanilla still commits placement. */
public final class DeskPlacement {
    public record Result(BlockPos pos,BlockState state,Direction expansion,boolean valid,BlockPlaceContext context) {}
    private DeskPlacement() {}
    public static Result resolve(Player player,InteractionHand hand,ItemStack stack,BlockHitResult hit) {
        if(!(stack.getItem() instanceof DeskBlockItem item))return null;
        var level=player.level();BlockState anchor=level.getBlockState(hit.getBlockPos());
        if(!(anchor.getBlock() instanceof DeskBlock)||BoardPlane.horizontal(anchor)!=((DeskBlock)item.getBlock()).horizontal())return null;
        Direction front=anchor.getValue(DeskBlock.FACING),right=BoardPlane.right(front),down=BoardPlane.down(front,BoardPlane.horizontal(anchor));
        Vec3 point=hit.getLocation().subtract(Vec3.atCenterOf(hit.getBlockPos()));
        double u=.5+point.x*right.getStepX()+point.z*right.getStepZ();
        double v=.5+point.x*down.getStepX()+point.y*down.getStepY()+point.z*down.getStepZ();
        double[] distances={u,1-u,v,1-v};int edge=0;
        for(int i=1;i<4;i++)if(distances[i]<distances[edge])edge=i;
        if(distances[edge]>.20)return null;
        Direction direction=switch(edge){case 0->right.getOpposite();case 1->right;case 2->down.getOpposite();default->down;};
        BlockPos target=hit.getBlockPos().relative(direction);
        BlockState state=item.getBlock().defaultBlockState().setValue(DeskBlock.FACING,front).setValue(DeskBlock.WALL,anchor.getValue(DeskBlock.WALL));
        var properties=stack.get(net.minecraft.core.component.DataComponents.BLOCK_STATE);if(properties!=null)state=properties.apply(state);
        BlockPlaceContext context=new AssistedContext(player,hand,stack,target,direction,state);
        boolean valid=!level.isOutsideBuildHeight(target)&&level.getBlockState(target).canBeReplaced(context)
            &&state.canSurvive(level,target)&&level.isUnobstructed(state,target,net.minecraft.world.phys.shapes.CollisionContext.of(player))
            &&level.mayInteract(player,target)&&player.mayUseItemAt(target,direction,stack)
            &&player.distanceToSqr(Vec3.atCenterOf(target))<=Math.pow(player.blockInteractionRange()+1,2);
        return new Result(target,state,direction,valid,context);
    }
    static final class AssistedContext extends BlockPlaceContext {
        final BlockPos target;final BlockState state;
        AssistedContext(Player p,InteractionHand hand,ItemStack stack,BlockPos target,Direction side,BlockState state){
            super(p.level(),p,hand,stack,new BlockHitResult(Vec3.atCenterOf(target),side,target,false));this.target=target;this.state=state;
        }
        @Override public BlockPos getClickedPos(){return target==null?super.getClickedPos():target;}
        @Override public boolean canPlace(){return getLevel().getBlockState(getClickedPos()).canBeReplaced(this);}
    }
}
