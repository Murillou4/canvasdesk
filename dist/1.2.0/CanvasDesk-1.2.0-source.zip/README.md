# Canvas Desk 1.2.0

Quadros e pranchetas modulares para **Minecraft Java 26.3**, **Fabric Loader 0.19.5**, **Fabric API 0.164.0+26.3** e **Java 25**. Madeira escura, cobre e papel acompanham desenhos, textos e diagramas persistidos no mundo.

## Instalação e atualização

Coloque `canvasdesk-1.2.0.jar` e a Fabric API na pasta `mods`, substituindo o JAR anterior do Canvas Desk. Em multiplayer, servidor e todos os clientes precisam usar a versão 1.2.0 e as mesmas versões de Minecraft e Fabric API. Não use dois JARs do Canvas Desk juntos.

Faça backup do mundo inteiro antes de atualizar. O ID `canvasdesk:desk`, os documentos, os vínculos dos itens e as projeções anteriores são preservados. Blocos antigos continuam verticais, brancos e com sua montagem central. A instalação pessoal não é alterada pelo empacotamento.

Este projeto é independente de MurilloUtils e Create. A entrega foi compilada e passou por testes unitários e validação estática de recursos. A validação desta versão dentro do jogo, incluindo colaboração real, permanece manual; veja `VALIDATION_STATUS.md`.

## Receitas e formatos

Qualquer tipo de tábuas pode ser usado. Cada receita base produz um módulo branco.

**Quadro vertical** (`canvasdesk:desk`):

```text
Papel   Papel    Papel
Cobre   Redstone Cobre
Tábuas  Tábuas   Tábuas
```

**Prancheta horizontal** (`canvasdesk:drawing_desk`), apoiada sobre blocos:

```text
Papel   Papel    Papel
Tábuas  Tábuas   Tábuas
Cobre   Redstone Cobre
```

Receitas sem formato, usando um módulo e um ingrediente:

| Entrada | Resultado |
| --- | --- |
| Módulo + qualquer um dos 16 corantes | Mesmo módulo com o fundo daquela cor |
| Quadro vertical + graveto | Prancheta horizontal |
| Prancheta horizontal + graveto | Quadro vertical |

As receitas de tingimento e conversão usam a transmutação vanilla, preservando o vínculo com o documento, a região e a cor existente quando aplicável. Corante branco restaura o fundo branco. A cor pertence a cada módulo, permitindo misturar fundos no mesmo conjunto.

Também é possível usar um corante diretamente em um módulo colocado. Isso exige acesso de edição ao documento, afeta somente o módulo clicado e consome um corante quando a cor muda. Em criativo, o corante é preservado. Os desenhos e suas cores continuam intactos.

## Colocação e superfície

O formato é escolhido pelo item. Olhar para baixo, pular ou girar a câmera não converte quadros em pranchetas. Quadros novos colocados na lateral de um bloco encostam na face clicada; colocação independente sobre um suporte usa orientação horizontal do jogador. Pranchetas permanecem planas.

Segure um módulo do mesmo formato e mire perto de uma das bordas de um módulo existente. A faixa de assistência ocupa os 20% mais próximos da borda. Uma seta e a geometria translúcida indicam o alvo e sua orientação; verde com `+` indica espaço válido, vermelho com `×` indica inválido. Clique direito confirma a expansão, herdando orientação e montagem. O servidor confirma espaço, colisão, alcance e permissões de colocação. No centro do quadro, o clique continua abrindo o editor.

Conectam-se módulos do mesmo documento, formato, orientação e plano. Uma união de documentos diferentes continua obedecendo às regras de consentimento. Uma prévia válida de colocação não concede propriedade nem aprovação de união.

Cada módulo corresponde a **256 × 256 unidades de documento**. As coordenadas crescem para a direita e para baixo em ambos os formatos. A moldura cobre uma faixa de 16 unidades nas bordas expostas; essa faixa fica marcada no editor e é revelada quando a borda passa a ser uma emenda conectada. Expansões preservam coordenadas, tamanho de fonte e tamanho dos desenhos.

## Editor compacto

Clique direito para abrir. O painel deixa margens do mundo visíveis, mantendo a maior área para escrita. A superfície é enquadrada na abertura. Enquanto você não navegar manualmente, alterações de módulos atualizam o enquadramento; depois de pan ou zoom manual, a câmera permanece onde foi deixada. **F** volta a enquadrar e acompanhar a superfície.

A cor e a moldura dos módulos aparecem no editor. Hachuras identificam vãos e exterior. Criação e interação direta começam na superfície disponível. Elementos podem atravessar emendas, bordas e buracos: o trecho sobre módulos aparece e pode ser selecionado; o restante permanece salvo para reaparecer em futuras expansões. Remover módulos nunca recorta os dados persistidos.

Seleção, Desfazer, Refazer e Enquadrar ficam juntos no canto superior esquerdo. A paleta abre cor, espessura e fonte; `…` oferece todas as ferramentas em resoluções menores. Dicas mostram os atalhos. Cliques nas margens do painel são consumidos pelo editor.

| Controle | Ação |
| --- | --- |
| V / B / E | Seleção / desenho / borracha |
| T / N / C | Texto direto / nota / lista |
| R / O / L / A / K | Retângulo / elipse / linha / seta / conector |
| H, Espaço + arraste ou botão do meio | Navegar |
| Roda do mouse | Zoom em torno do cursor |
| F | Enquadrar a superfície |
| Shift + seleção | Acrescentar à seleção |
| Alt + clique | Selecionar elementos visíveis do grupo |
| Enter / duplo clique | Editar o texto selecionado |
| Ctrl + Enter | Finalizar texto direto ou salvar o cartão |
| Delete / Backspace | Excluir seleção fora da digitação |
| Ctrl + Z / Ctrl + Y | Desfazer / refazer |
| F1 ou `?` | Ajuda e opção de sons |
| Esc | Finalizar digitação, fechar diálogo ou fechar editor |

Arraste em espaço vazio para selecionar vários elementos. A borracha remove elementos completos, incluindo seus trechos ocultos, quando eles são atingidos pela parte visível. O canto inferior direito redimensiona. Conectores acompanham os elementos ligados. Fonte e marcações de listas permanecem salvas e participam do histórico individual.

## Texto direto, gravação e áudio

Texto comum é digitado sobre o canvas, com cursor, seleção, acentos, composição, clipboard e quebras de linha. Notas e checklists continuam usando cartões. Durante a digitação, teclas como V, B, T e Espaço pertencem ao texto. Enter quebra linha; Ctrl+Enter ou Esc finaliza a edição. O redimensionamento de TEXT escala proporcionalmente a fonte, entre 8 e 96 unidades. A seleção acompanha o conteúdo medido; textos antigos mantêm a largura de quebra existente.

A gravação ocorre após 750 ms sem alterações e, em escrita contínua, em checkpoints a cada 5 segundos. Há apenas uma operação de escrita em voo, mantendo a digitação local livre. Checkpoints consecutivos do mesmo intervalo formam uma ação de desfazer. Pausas, troca de foco e alterações intervenientes encerram o agrupamento. O indicador de gravação depende da confirmação durável do servidor.

Ao fechar, o editor aguarda as alterações pendentes. Em conflito, o rascunho continua disponível para copiar antes de recarregar a versão do servidor; nenhuma alteração remota é sobrescrita automaticamente. Saídas inesperadas com texto pendente tentam guardar uma cópia local em `config/canvasdesk-unsaved-text.json`. Esse arquivo é um rascunho de recuperação, e não uma confirmação de gravação no mundo.

Se o módulo aberto for removido, a sessão procura outro módulo carregado do conjunto anterior dentro do alcance de 10 blocos, preservando a câmera. Sem candidato, fecha com aviso. Remover uma ponte faz cada editor representar seu fragmento físico, mantendo o documento compartilhado.

**Sons do editor** fica em `?`/F1, desligado por padrão. O feedback adicional de digitação e ações é discreto, limitado em frequência e respeita volume geral e de blocos. A preferência fica em `config/canvasdesk-client.json`. O editor não altera os volumes nem interrompe o motor de áudio; o relato de ausência dos sons normais ainda precisa de confirmação no jogo.

## Documentos, conexões e acesso

- Quebrar um módulo devolve um item vinculado. Recolocado isoladamente, ele restaura sua região; conectado, adota a projeção da superfície existente.
- Partes separadas continuam ligadas ao mesmo documento. Remover uma ponte não divide nem copia desenhos. Descarregar chunks preserva a superfície conhecida.
- Reconexões com projeções diferentes preservam a superfície mais antiga, podendo mudar a região exibida pela outra parte sem mover os elementos do documento.
- Documentos do mesmo dono podem unir automaticamente quando esse dono fizer a conexão. Donos diferentes precisam aprovar em **Acesso e uniões**; donos e convidados resultantes aparecem antes da aprovação.
- A união preserva identidades e grupos de origem. O histórico anterior à união é reiniciado para evitar operações em coordenadas antigas.
- Donos convidam e removem editores. Outros jogadores próximos podem ler. Quebra de blocos continua seguindo as regras do mundo.
- O histórico mantém até 100 ações por jogador e recusa desfazer silenciosamente uma alteração posterior de outro jogador.

## Recuperação e backup

```text
/canvasdesk list
/canvasdesk recover <UUID-do-documento>
```

Donos recuperam seus documentos; operadores podem recuperar administrativamente. Recuperar produz outra referência ao mesmo documento. Itens transportados de outro mundo preservam o vínculo desconhecido, sem importar conteúdo ausente nem criar um documento substituto.

Faça backup do **mundo inteiro**, incluindo a pasta `canvasdesk`, seus documentos, objetos imutáveis, snapshots, índice e journal. Não copie apenas o snapshot e não edite os arquivos durante o jogo. Registros e objetos antigos permanecem para recuperação; não há limpeza destrutiva automática.

Alterações confirmadas permanecem recuperáveis após queda. Os chunks vanilla são reconciliados separadamente: uma união confirmada pode sobreviver mesmo que Minecraft reverta o bloco que conectava as partes.

## Compilação e evidências

Toolchain fixada: Gradle 9.6.0, Loom 1.17.21, Java 25 e as versões de Minecraft/Fabric indicadas acima.

```powershell
$env:JAVA_HOME = 'C:\caminho\para\jdk-25'
$env:Path = "$env:JAVA_HOME\bin;$env:Path"
.\gradlew.bat --no-daemon --console=plain release -x test -x check
```

`dist/1.2.0` contém JAR, JAR de fontes, projeto fonte ZIP, documentação e `SHA256SUMS.txt`. Classes de GameTest e validação de desenvolvimento não entram no JAR distribuível.

Testes unitários limitados a dois minutos, sem abrir Minecraft:

```powershell
.\gradlew.bat --no-daemon --console=plain test --tests '*CanvasStoreTest' --tests '*SurfaceLayoutTest'
```

Recursos são gerados de `art/geometry.json` e dos scripts em `tools/`. `python tools/generate-assets.py` apenas gera; `--validate` acrescenta verificações estáticas, sem cliente. A renderização mantém cache LRU de pixels de 32 MiB e resolução 256 próxima/64 distante. Máscaras e índices físicos são reconstruídos quando a topologia muda, sem buscas completas por frame. Documentos permanecem vetoriais.

Consulte `VALIDATION_STATUS.md` para resultados desta versão e o roteiro manual. Evidências antigas da versão 1.1.0 não aprovam a versão 1.2.0.

Licença MIT. Não é um produto oficial de Minecraft, Mojang ou Microsoft.
